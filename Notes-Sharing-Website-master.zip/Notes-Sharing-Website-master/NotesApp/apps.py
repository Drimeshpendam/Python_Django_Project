from django.apps import AppConfig


class NotesappConfig(AppConfig):
    name = 'NotesApp'

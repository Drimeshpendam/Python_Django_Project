from django.contrib import admin
from NotesApp.models import *
# Register your models here.

admin.site.register(Signup)
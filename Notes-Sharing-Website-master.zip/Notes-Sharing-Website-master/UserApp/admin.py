from django.contrib import admin
from UserApp.models import *
# Register your models here.

admin.site.register(Notes)